import { Component} from "react";
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import HeaderBlock from "../headerBlock/headerBlock";
import HeroesList from "../heroesList/HeroesList";
import AuthorizationBlock from "../authorizationBlock/authorizationBlock"
import ComicsCart from '../comicsCart/comicsCart'

class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      orderList: []
    }
  }

  addToCart = (order) => {

    this.state.orderList.find(el => {
      if (el.id === order.id) {
        this.setState({orderList: [el.count++]})
      }
    })
    this.setState({orderList: [...this.state.orderList, order]})
  }


  render () { 
 
  return (
    <BrowserRouter>
    <div className="mx-auto my-0 w-[1200px] py-12">
      <HeaderBlock/>
      <main className="flex">
      <Routes>
          <Route path='/' element={<HeroesList addToCart={this.addToCart}/>}/>    
          {/* <Route path='/' element={<AuthorizationBlock/>}/> */}
          <Route path='/cart' element={<ComicsCart orders={this.state.orderList}/>}/>
      </Routes>
      </main>
    </div>
    </BrowserRouter>
  );
  }
}

export default App;
