import {Component} from "react";

class ComicsCart extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    createOrderCard = (arr) => {
        return arr.map(order => {
            const {id, title, price, thumbnail, count} = order
            return (
                <li key={id}>
                    <p>
                        {title}
                    </p>
                    <div className="w-[100px] h-[100px]">
                        <img className="h-full" src={thumbnail} alt="" />
                    </div>
                    <p>
                        Curent price: {price}
                    </p>
                    <p>
                        Current count: {count}
                    </p>
                </li>
            )
        })
    }

    render() {

        console.log(this.props.orders);

        // const {orders} = this.props.orders
        const orderCard = this.createOrderCard(this.props.orders)

        return (
            <div>
                <ul>
                    {orderCard}
                </ul>
            </div>
        )
    }
}

export default ComicsCart;